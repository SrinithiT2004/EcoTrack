<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: auth_gateway.php");
    exit();
}

// 1. CREATE: Handle form processing for onboarding an asset
if (isset($_POST['add_asset'])) {
    $name = trim($_POST['asset_name']);
    $cat = $_POST['category'];
    $watts = intval($_POST['power_rating_watts']);
    $years = intval($_POST['lifespan_years']);
    $p_date = $_POST['purchase_date'];
    $user_assign = empty($_POST['assigned_user_id']) ? NULL : intval($_POST['assigned_user_id']);

    $stmt = $conn->prepare("INSERT INTO assets (asset_name, category, power_rating_watts, lifespan_years, purchase_date, assigned_user_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiisi", $name, $cat, $watts, $years, $p_date, $user_assign);
    $stmt->execute();
    header("Location: manage_assets.php");
    exit();
}

// 2. UPDATE: Handle changes to operational status
if (isset($_POST['update_status'])) {
    $aid = intval($_POST['asset_id']);
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE assets SET operational_status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $aid);
    $stmt->execute();
    header("Location: manage_assets.php");
    exit();
}

// 3. DELETE: Safe clean removal from local registry
if (isset($_GET['delete_id'])) {
    $did = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM assets WHERE id = ?");
    $stmt->bind_param("i", $did);
    $stmt->execute();
    header("Location: manage_assets.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>EcoTrack - Sustainability Management Panel</title>
    <style>
        body { font-family: sans-serif; background: #f8fafc; margin: 0; padding: 20px; color: #334155; }
        .nav { display: flex; justify-content: space-between; background: white; padding: 15px 30px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 20px;}
        .layout { display: grid; grid-template-columns: 1fr 3fr; gap: 20px; }
        .card { background: white; padding: 20px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        input, select, button { width: 100%; padding: 8px; margin: 6px 0; border: 1px solid #cbd5e1; border-radius: 4px; box-sizing: border-box; }
        button { background: #16a34a; color: white; border: none; font-weight: bold; cursor: pointer; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 10px; border-bottom: 1px solid #e2e8f0; text-align: left; font-size: 0.9em; }
        th { background: #f1f5f9; }
        .action-links { display: flex; gap: 10px; align-items: center; }
    </style>
</head>
<body>

<div class="nav">
    <h2>EcoTrack Administrator Panel</h2>
    <div>
        <a href="metrics_report.php" style="margin-right:20px; font-weight:bold; color:#16a34a; text-decoration:none;">Carbon Sustainability Report</a>
        <a href="signout.php" style="color:#ef4444; font-weight:bold; text-decoration:none;">Logout</a>
    </div>
</div>

<div class="layout">
    <div class="card">
        <h3>Asset Onboarding</h3>
        <form action="manage_assets.php" method="POST">
            <input type="text" name="asset_name" placeholder="Asset Identifier (e.g. Dell XPS 15)" required>
            <select name="category">
                <option value="Laptop">Laptop</option>
                <option value="Monitor">Monitor</option>
                <option value="Server">Server</option>
                <option value="Networking">Networking</option>
            </select>
            <input type="number" name="power_rating_watts" placeholder="Power Consumed (Watts)" min="1" required>
            <input type="number" name="lifespan_years" placeholder="Expected Operational Life (Years)" min="1" required>
            <input type="date" name="purchase_date" required>
            
            <select name="assigned_user_id">
                <option value="">Leave Unassigned</option>
                <?php
                $users = $conn->query("SELECT id, username FROM users WHERE user_role = 'employee'");
                while ($u = $users->fetch_assoc()) echo "<option value='{$u['id']}'>@{$u['username']}</option>";
                ?>
            </select>
            <button type="submit" name="add_asset">Register New Asset</button>
        </form>
    </div>

    <div class="card">
        <h3>Corporate Asset Catalog</h3>
        <table>
            <thead>
                <tr>
                    <th>Asset Details</th>
                    <th>Metric Metrics</th>
                    <th>Status Controls</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $inventory = $conn->query("SELECT a.*, u.username FROM assets a LEFT JOIN users u ON a.assigned_user_id = u.id ORDER BY a.id DESC");
                while ($row = $inventory->fetch_assoc()):
                ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($row['asset_name']); ?></strong><br>
                        <span style="color:#64748b; font-size:0.85em;">Type: <?php echo $row['category']; ?> | Assignee: <?php echo $row['username'] ? '@'.$row['username'] : 'None'; ?></span>
                    </td>
                    <td><?php echo $row['power_rating_watts']; ?>W / <?php echo $row['lifespan_years']; ?> Yrs</td>
                    <td>
                        <form action="manage_assets.php" method="POST" style="margin:0; display:flex; gap:5px;">
                            <input type="hidden" name="asset_id" value="<?php echo $row['id']; ?>">
                            <select name="status" style="width:110px; padding:3px; margin:0;">
                                <option value="Active" <?php if($row['operational_status']=='Active') echo 'selected'; ?>>Active</option>
                                <option value="In-Repair" <?php if($row['operational_status']=='In-Repair') echo 'selected'; ?>>In-Repair</option>
                                <option value="E-Waste" <?php if($row['operational_status']=='E-Waste') echo 'selected'; ?>>E-Waste</option>
                            </select>
                            <button type="submit" name="update_status" style="width:60px; padding:3px; margin:0; background:#3b82f6;">Update</button>
                        </form>
                    </td>
                    <td>
                        <a href="manage_assets.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Deregister this asset permanently?')" style="color:#ef4444; text-decoration:none; font-size:0.9em;">Remove</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>