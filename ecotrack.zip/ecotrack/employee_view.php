<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: auth_gateway.php");
    exit();
}

$my_uid = $_SESSION['uid'];

// Handle ticket logging submission
if (isset($_POST['log_fault'])) {
    $asset_id = intval($_POST['asset_id']);
    $desc = trim($_POST['issue_description']);

    $stmt = $conn->prepare("INSERT INTO fault_reports (asset_id, issue_description) VALUES (?, ?)");
    $stmt->bind_param("is", $asset_id, $desc);
    if ($stmt->execute()) {
        // Automatically put asset under repair evaluation state
        $update = $conn->query("UPDATE assets SET operational_status = 'In-Repair' WHERE id = $asset_id");
        echo "<script>alert('Fault filed. Asset marked for structural repair assessment.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>EcoTrack - Employee Asset Console</title>
    <style>
        body { font-family: sans-serif; background: #f8fafc; margin: 0; padding: 20px; }
        .nav { display: flex; justify-content: space-between; background: white; padding: 15px 30px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 20px;}
        .container { max-width: 900px; margin: 0 auto; display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
        .card { background: white; padding: 20px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        textarea, button, select { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #cbd5e1; border-radius: 4px; box-sizing: border-box; }
        button { background: #ef4444; color: white; border: none; font-weight: bold; cursor: pointer; }
        .asset-item { border: 1px solid #e2e8f0; padding: 12px; margin-bottom: 10px; border-radius: 4px; }
    </style>
</head>
<body>

<div class="nav">
    <h2>EcoTrack Employee Portal</h2>
    <a href="signout.php" style="color:#ef4444; font-weight:bold; text-decoration:none;">Logout</a>
</div>

<div class="container">
    <div class="card">
        <h3>Your Tracked Hardware Resources</h3>
        <?php
        $my_assets = $conn->query("SELECT * FROM assets WHERE assigned_user_id = $my_uid");
        if ($my_assets->num_rows > 0):
            while ($row = $my_assets->fetch_assoc()):
        ?>
            <div class="asset-item">
                <strong><?php echo htmlspecialchars($row['asset_name']); ?></strong> 
                <span style="float:right; font-weight:bold; color:<?php echo $row['operational_status']=='Active'?'#16a34a':'#eab308';?>">
                    [<?php echo $row['operational_status']; ?>]
                </span><br>
                <small style="color:#64748b;">Category: <?php echo $row['category']; ?> | System power pull: <?php echo $row['power_rating_watts']; ?> Watts</small>
            </div>
        <?php 
            endwhile;
        else:
            echo "<p style='color:#94a3b8;'>No hardware currently cataloged to your workspace profile.</p>";
        endif; 
        ?>
    </div>

    <div class="card">
        <h3>Report Asset Malfunction</h3>
        <form action="employee_view.php" method="POST">
            <label>Select Target Hardware:</label>
            <select name="asset_id" required>
                <?php
                $my_assets = $conn->query("SELECT id, asset_name FROM assets WHERE assigned_user_id = $my_uid AND operational_status = 'Active'");
                while($row = $my_assets->fetch_assoc()) echo "<option value='{$row['id']}'>{$row['asset_name']}</option>";
                ?>
            </select>
            <textarea name="issue_description" placeholder="Describe symptoms or breakdown event..." rows="4" required></textarea>
            <button type="submit" name="log_fault">Submit Damage Report</button>
        </form>
    </div>
</div>

</body>
</html>