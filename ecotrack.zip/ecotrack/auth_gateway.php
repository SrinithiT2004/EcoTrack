<?php
session_start();
require_once 'db_config.php';

if (isset($_SESSION['uid'])) {
    header("Location: " . ($_SESSION['role'] === 'admin' ? 'manage_assets.php' : 'employee_view.php'));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username']);
    $pass = $_POST['password'];
    $mode = $_POST['mode']; // 'login' or 'register'

    if ($mode === 'register') {
        $role = $_POST['role'];
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO users (username, password_hash, user_role) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $user, $hash, $role);
        
        if ($stmt->execute()) {
            echo "<script>alert('Account created! Proceed to log in.');</script>";
        } else {
            echo "<script>alert('Error: Username already exists.');</script>";
        }
    } elseif ($mode === 'login') {
        $stmt = $conn->prepare("SELECT id, password_hash, user_role FROM users WHERE username = ?");
        $stmt->bind_param("s", $user);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($account = $res->fetch_assoc()) {
            if (password_verify($pass, $account['password_hash'])) {
                $_SESSION['uid'] = $account['id'];
                $_SESSION['username'] = $user;
                $_SESSION['role'] = $account['user_role'];
                
                header("Location: " . ($account['user_role'] === 'admin' ? 'manage_assets.php' : 'employee_view.php'));
                exit();
            }
        }
        echo "<script>alert('Invalid security credentials supplied.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>EcoTrack - Entry Gateway</title>
    <style>
        body { font-family: sans-serif; background: #f0fdf4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); width: 300px; }
        input, select, button { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #bbf7d0; border-radius: 4px; box-sizing: border-box; }
        button { background: #16a34a; color: white; border: none; font-weight: bold; cursor: pointer; }
        .toggle { text-align: center; font-size: 0.85em; color: #16a34a; cursor: pointer; margin-top: 10px; }
    </style>
</head>
<body>
<div class="box">
    <h2 id="title" style="text-align:center; color:#15803d;">EcoTrack Login</h2>
    <form action="auth_gateway.php" method="POST">
        <input type="text" name="username" placeholder="Username ID" required>
        <input type="password" name="password" placeholder="Password Security Key" required>
        <div id="role-box" style="display:none;">
            <label>System Privilege Level:</label>
            <select name="role"><option value="employee">Standard Employee</option><option value="admin">Sustainability Administrator</option></select>
        </div>
        <input type="hidden" name="mode" id="form-mode" value="login">
        <button type="submit" id="btn">Sign In</button>
    </form>
    <div class="toggle" id="switch" onclick="toggleView()">Need a new account? Register here.</div>
</div>
<script>
function toggleView() {
    const mode = document.getElementById('form-mode');
    const title = document.getElementById('title');
    const btn = document.getElementById('btn');
    const rBox = document.getElementById('role-box');
    const sw = document.getElementById('switch');

    if (mode.value === 'login') {
        mode.value = 'register'; title.innerText = 'EcoTrack Registration';
        btn.innerText = 'Register System Profile'; rBox.style.display = 'block';
        sw.innerText = 'Existing profile? Return to Login.';
    } else {
        mode.value = 'login'; title.innerText = 'EcoTrack Login';
        btn.innerText = 'Sign In'; rBox.style.display = 'none';
        sw.innerText = 'Need a new account? Register here.';
    }
}
</script>
</body>
</html>